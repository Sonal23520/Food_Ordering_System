create definer = root@localhost trigger res_id
    before insert
    on restaurant
    for each row
BEGIN
 SET NEW.restaurant_id = (SELECT MAX(restaurant_id) + 4 FROM restaurant);
 END;

