create
    definer = root@localhost procedure order_list()
SELECT o.order_id ,o.customer_id,m.menu_name,p.payment_type,CONCAT(c.phone_no,' ,',c.state,' ,',c.city,' ,',c.landmark,' ,',c.pincode) AS Address,o.quantity as Qnt FROM orders o INNER JOIN menu m ON m.menu_id=o.menu_id INNER JOIN payment p ON p.order_id=o.order_id INNER JOIN customer c ON c.customer_id=o.customer_id WHERE o.order_status='PAYMENT_CONFIRMED' ORDER BY p.time_stamp ASC;

