package lk.com.foodOrdering.bo;

public interface SuperBo {
}
