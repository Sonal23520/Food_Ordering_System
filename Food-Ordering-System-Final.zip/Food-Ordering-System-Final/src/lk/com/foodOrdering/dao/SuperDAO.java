package lk.com.foodOrdering.dao;

public interface SuperDAO {
}
