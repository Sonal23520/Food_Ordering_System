package lk.com.foodOrdering.dao.custom;

import lk.com.foodOrdering.dao.CrudDAO;
import lk.com.foodOrdering.entity.RestaurantEntity;

public interface RestaurantDAO extends CrudDAO<RestaurantEntity,String> {
}
