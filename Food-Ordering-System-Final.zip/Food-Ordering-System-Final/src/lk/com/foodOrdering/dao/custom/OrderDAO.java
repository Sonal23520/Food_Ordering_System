package lk.com.foodOrdering.dao.custom;

import lk.com.foodOrdering.dao.CrudDAO;
import lk.com.foodOrdering.entity.OrderEntity;

public interface OrderDAO extends CrudDAO<OrderEntity,String> {
}
