package lk.com.foodOrdering.dao.custom;

import lk.com.foodOrdering.dao.CrudDAO;
import lk.com.foodOrdering.entity.CustomerEntity;

public interface CustomerDAO extends CrudDAO<CustomerEntity,String> {
}
