package lk.com.foodOrdering.dao.custom;

import lk.com.foodOrdering.dao.CrudDAO;
import lk.com.foodOrdering.entity.PaymentEntity;

public interface PaymentDAO extends CrudDAO<PaymentEntity,String> {
}
