package lk.com.foodOrdering.dao.custom;

import lk.com.foodOrdering.dao.CrudDAO;
import lk.com.foodOrdering.entity.MenuEntity;

public interface MenuDAO extends CrudDAO<MenuEntity,String> {
}
