package lk.com.foodOrdering.dao.custom;

import lk.com.foodOrdering.dao.CrudDAO;
import lk.com.foodOrdering.entity.OrderDetailEntity;

public interface OrderDetailDAO extends CrudDAO<OrderDetailEntity,String> {
}
