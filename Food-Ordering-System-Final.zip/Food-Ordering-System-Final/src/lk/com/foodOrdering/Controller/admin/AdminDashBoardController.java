package lk.com.foodOrdering.Controller.admin;

import com.jfoenix.controls.JFXButton;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import lk.com.foodOrdering.setUI.SetUI;
import lk.com.foodOrdering.setUI.SuperSetUI;

import java.net.URL;
import java.util.ResourceBundle;
public class AdminDashBoardController implements Initializable {
    public ImageView lblCancel;
    public JFXButton btnMangeCustomer;
    public Label lblTitle;
    public JFXButton btnManageEmploye;
    public JFXButton btnManageItem;
    public JFXButton btnOrderDetail;
    public JFXButton btnHome;
    SuperSetUI superSetUI=new SetUI();
    @FXML
    private AnchorPane root;

    @FXML
    void dashBoard(ActionEvent event) throws Exception {
        superSetUI.setFxml(root, "lk/com/foodOrdering/view/Admin/DefaultPanel.fxml");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            superSetUI.setFxml(root, "lk/com/foodOrdering/view/Admin/DefaultPanel.fxml");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void cancel(MouseEvent mouseEvent) {
        System.exit(0);
    }

    public void manageCustomer(ActionEvent actionEvent) throws Exception {
        lblTitle.setText(btnMangeCustomer.getText());
        superSetUI.setFxml(root, "lk/com/foodOrdering/view/Admin/UpdateCustomer.fxml");
    }

    public void manageEmployee(ActionEvent actionEvent) throws Exception {
        lblTitle.setText(btnManageEmploye.getText());
        superSetUI.setFxml(root, "lk/com/foodOrdering/view/Admin/UpdateEmploye.fxml");

    }

    public void manageItem(ActionEvent actionEvent) throws Exception {
        lblTitle.setText(btnManageItem.getText());
        superSetUI.setFxml(root, "lk/com/foodOrdering/view/Admin/UpdateMenu.fxml");

    }

    public void backToHome(ActionEvent actionEvent) throws Exception {
        superSetUI.setUI(actionEvent, "lk/com/foodOrdering/view/Admin/Login.fxml");
    }

    public void orderDetailOnAction(ActionEvent actionEvent) throws Exception {
        lblTitle.setText(btnOrderDetail.getText());
        superSetUI.setFxml(root, "lk/com/foodOrdering/view/Admin/OrderDetailForm.fxml");

    }

//    public void translateTransaction(int a, int b) {
//        TranslateTransition slide = new TranslateTransition();
//        slide.setDuration(Duration.seconds(0.4));
//        slide.setNode(root);
//        slide.setToX(a);
//        slide.play();
//
//        root.setTranslateX(b);
//    }
}
