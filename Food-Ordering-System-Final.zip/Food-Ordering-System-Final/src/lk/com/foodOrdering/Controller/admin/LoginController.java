package lk.com.foodOrdering.Controller.admin;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import lk.com.foodOrdering.setUI.SetUI;
import lk.com.foodOrdering.setUI.SuperSetUI;

public class LoginController {

    public JFXTextField idtxt;
    public AnchorPane root;
    @FXML
    private JFXTextField emptxt;

    @FXML
    private JFXPasswordField passtxt;
    SuperSetUI superSetUI=new SetUI();

    @FXML
    void Login(ActionEvent event) throws Exception {

        superSetUI.setUI(event, "lk/com/foodOrdering/view/Admin/AdminDashBoard.fxml");
//        translateTransaction(300,0);
    }

    @FXML
    void exitScreen(ActionEvent event) {
        System.exit(0);
    }

    public void backToHome(MouseEvent mouseEvent) throws Exception {
        superSetUI.setUI(mouseEvent, "lk/com/foodOrdering/view/user/Welcome.fxml");

    }

//    public void translateTransaction(int a, int b) {
//        TranslateTransition slide = new TranslateTransition();
//        slide.setDuration(Duration.seconds(0.4));
//        slide.setNode(root);
//        slide.setToX(a);
//        slide.play();
//
//       root.setTranslateX(b);
//    }
}
